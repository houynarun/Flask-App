import setuptools

setuptools.setup(
   name='pkg-prod',
   license='Testing MIT',
   version='0.3.0',
   description='Testing Package',
   long_description ='Testing Package',
   author='QA',
   author_email='qa@morakot.it',
   url='https://www.morakot.it',
   # package_dir={'': ''},
   data_files=[
    ('',['favo.png','NEWS.rst'])
   ], 
   project_url = "Document, ['fa fa-edit', 'https://google.com']",
   install_requires=['flake8'],
   classifiers=[
       'Topic :: Software Development :: Quality Assurance',
   ],
)
